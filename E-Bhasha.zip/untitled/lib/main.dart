import 'dart:convert';

import 'package:avatar_glow/avatar_glow.dart';
import 'package:flutter/material.dart';
import 'package:flutter_speech/flutter_speech.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: VoiceHome(),
    );
  }
}

class VoiceHome extends StatefulWidget {
  @override
  _VoiceHomeState createState() => _VoiceHomeState();
}

class _VoiceHomeState extends State<VoiceHome> {
  SpeechRecognition _speechRecognition = SpeechRecognition();
  bool _isAvailable = false;
  bool _isListening = false;
  bool _isListening2 = false;

  String recordedText = "Press the mic button and start speaking";
  String convertedText = "Your answer will shown here";
  bool isListening = false;
  String language = "hindi";
  String language2 = "hindi";
  int mic1 = 0;
  int mic2 = 0;
  var myLanguage = [
    "hindi",
    "english",
    "tamil",
    "punjabi",
    "gujarati",
    "kannada",
    "malayalam",
    "marathi",
    "telugu",
    "bengali"
  ];
  var myLanguage2 = [
    "hindi",
    "english",
    "tamil",
    "punjabi",
    "gujarati",
    "kannada",
    "malayalam",
    "marathi",
    "telugu",
    "bengali"
  ];
  var localeLang = {
    "hindi": "hi_IN",
    "bengali": "bn_IN",
    "gujarati": "gu_IN",
    "kannada": "kn_IN",
    "malayalam": "ml_IN",
    "marathi": "mr_IN",
    "punjabi": "pa_IN",
    "tamil": "ta_IN",
    "telugu": "te_IN",
    "english": "en_US"
  };
  final FlutterTts flutterTts = FlutterTts();
  final TextEditingController textEditingController = TextEditingController();

  String resultText = "Press the mic button and start speaking";

  var langList1 = [];
  var langList2 = [];

  final padding = const EdgeInsets.all(4.0);
  final border = RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(10.0),
    side: const BorderSide(
      color: Colors.purple,
      width: 2,
    ),
  );

  @override
  void initState() {
    super.initState();
    initSpeechRecognizer();
  }

  void initSpeechRecognizer() {
    print("###################################");
    _speechRecognition = SpeechRecognition();

    _speechRecognition.setAvailabilityHandler(
      (bool result) => setState(() => _isAvailable = result),
    );

    // _speechRecognition.setRecognitionStartedHandler(
    //       () => setState(() => _isListening = true),
    // );

    // _speechRecognition.setRecognitionResultHandler(
    //       (String speech) => setState(
    //         () => resultText = speech,
    //   ),
    // );

    // _speechRecognition.setRecognitionCompleteHandler(
    //       (String speech) => setState(() => _isListening = false),
    // );

    _speechRecognition.setErrorHandler(() => initSpeechRecognizer());

    _speechRecognition.activate("hi_IN").then(
          (result) => setState(() => _isAvailable = result),
        );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("E-Bhasha"),
        centerTitle: true,
      ),
      body: Container(
        //1
        padding: const EdgeInsets.all(16),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: [
            Wrap(
              children: [
                Container(
                  alignment: Alignment.center,
                  margin: const EdgeInsets.only(),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          // color: Color.fromARGB(255, 231, 237, 248),
                          padding: const EdgeInsets.only(
                              right: 16, top: 16, bottom: 16, left: 16),
                          margin: const EdgeInsets.only(right: 16),
                          alignment: Alignment.centerLeft,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 222, 233, 252),
                            border: Border.all(
                              width: 1,
                              color: const Color.fromARGB(255, 39, 39, 176),
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            recordedText = recordedText,
                          ),
                        ),
                      ),
                      DropdownButton(
                        alignment: Alignment.center,
                        items: myLanguage.map((String dropDownStringItem) {
                          return DropdownMenuItem<String>(
                            value: dropDownStringItem,
                            child: Text(
                              dropDownStringItem,
                            ),
                          );
                        }).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            language = newValue!;
                          });
                        },
                        value: language,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 32,
            ),
            Wrap(
              children: [
                Container(
                  margin: const EdgeInsets.only(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.only(right: 16),
                          padding: const EdgeInsets.only(
                              right: 16, top: 16, bottom: 16, left: 16),
                          alignment: Alignment.centerLeft,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                            color: const Color.fromARGB(255, 222, 233, 252),
                            border: Border.all(
                              width: 1,
                              color: const Color.fromARGB(255, 39, 39, 176),
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            convertedText = convertedText,
                          ),
                        ),
                      ),
                      DropdownButton(
                        alignment: Alignment.center,
                        items: myLanguage2.map((String dropDownStringItem) {
                          return DropdownMenuItem<String>(
                            value: dropDownStringItem,
                            child: Text(
                              dropDownStringItem,
                            ),
                          );
                        }).toList(),
                        onChanged: (newValue) {
                          setState(() {
                            language2 = newValue!;
                          });
                        },
                        value: language2,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                AvatarGlow(
                  animate: _isListening,
                  endRadius: 55,
                  glowColor: Colors.blue,
                  child: FloatingActionButton(
                    onPressed: start,
                    child: Icon(
                      _isListening ? Icons.mic : Icons.mic_none,
                      size: 36,
                    ),
                  ),
                ),
                const SizedBox(
                  height: 8,
                ),
                AvatarGlow(
                  animate: _isListening2,
                  endRadius: 55,
                  glowColor: Colors.blue,
                  child: FloatingActionButton(
                    onPressed: start2,
                    child: Icon(
                      _isListening2 ? Icons.mic : Icons.mic_none,
                      size: 36,
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              child: GridView.builder(
                  itemCount: langList1.length,
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 1, childAspectRatio: 2.8),
                  itemBuilder: (context, index) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.all(8),
                      padding: const EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 222, 233, 252),
                        border: Border.all(
                          width: 1,
                          color: const Color.fromARGB(255, 39, 39, 176),
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: SizedBox(
                        height: 50, // set the height of the container
                        child: Text(
                          '${langList1[index]}\n\n${langList2[index]}',
                          style: const TextStyle(
                            height: 1.0,
                            fontSize: 16,
                          ),
                        ),
                      ),
                    );
                  }

                  // itemBuilder: (context, index) => GridTile(
                  //   child:Expanded(
                  //     child: Card(
                  //       shape: border,
                  //       color: Colors.white,
                  //       // child: Center(child: (Text(langList1[index].toString()+'\n\n'+langList2[index].toString()))),
                  //       child: Center(
                  //         child: Padding(
                  //           // padding: EdgeInsets.all(0),
                  //           padding: const EdgeInsets.only(left:16, bottom: 16, right: 16, top:16),
                  //           child: Text(
                  //             '${langList1[index]}\n\n${langList2[index]}',
                  //           ),
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  ),
            ),
            const SizedBox(
              height: 8,
            ),
            const Text("powered by iiita",textAlign: TextAlign.end),
            // ElevatedButton(
            //   onPressed: () async {
            //     if(mic1==1){
            //       mic2=0;
            //       const url = "http://rahuldev153.pythonanywhere.com/api";
            //       final response = await http.post(Uri.parse(url),
            //           headers: {"Content-Type": "application/json"},
            //           body:
            //           json.encode({'text': recordedText, 'lang': language2}));
            //       print("language2"+"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
            //
            //       if (isListening == true) {
            //         stop();
            //       }
            //       convertedText = response.body;
            //       print(convertedText + "******************************");
            //       setState(() {
            //         convertedText = response.body;
            //         langList1.add(recordedText);
            //         langList2.add(convertedText);
            //         speak(convertedText);
            //       });
            //     }
            //     else if(mic2==1){
            //       mic1=0;
            //       const url = "http://rahuldev153.pythonanywhere.com/api";
            //       final response = await http.post(Uri.parse(url),
            //           headers: {"Content-Type": "application/json"},
            //           body:
            //           json.encode({'text': convertedText, 'lang': language}));
            //       print("language2"+"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
            //
            //       if (isListening == true) {
            //         stop();
            //       }
            //       recordedText = response.body;
            //       print(recordedText + "******************************");
            //       setState(() {
            //         recordedText = response.body;
            //         langList1.add(convertedText);
            //         langList2.add(recordedText);
            //         speak(recordedText);
            //       });
            //     }
            //   },
            //   child: const Text("Convert", style: TextStyle(fontSize: 18)),
            // ),
          ],
        ),
      ),
    );
  }

  void start() {
    mic1 = 1;
    String loc = "";
    if (localeLang[language] == null) {
      loc = "hi_IN";
    } else {
      loc = localeLang[language]!;
    }
    _speechRecognition.activate(loc).then(
          (result) => setState(() => _isAvailable = result),
        );
    _speechRecognition.setRecognitionStartedHandler(
      () => setState(() => _isListening = true),
    );
    _speechRecognition.setRecognitionResultHandler(
      (String speech) => setState(
        () => recordedText = speech,
      ),
    );
    _speechRecognition.setRecognitionCompleteHandler(
      (String speech) => setState(() => _isListening = false),
    );
    if (_isAvailable && !_isListening) {
      _speechRecognition
          .listen()
          .then((result) => setState(() => recordedText = recordedText));
    }
    Future.delayed(Duration(seconds: 5), () {
      convert();
    });
  }

  Future<void> convert() async {
    const url = "http://rahuldev153.pythonanywhere.com/api";
    final response = await http.post(Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode({'text': recordedText, 'lang': language2}));
    print("language2" + "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

    if (isListening == true) {
      stop();
    }
    convertedText = response.body;
    print(convertedText + "******************************");
    setState(() {
      convertedText = response.body;
      langList1.add(recordedText);
      langList2.add(convertedText);
      speak(convertedText);
    });
  }

  void start2() {
    mic2 = 1;
    String loc = "";
    if (localeLang[language2] == null) {
      loc = "hi_IN";
    } else {
      loc = localeLang[language2]!;
    }
    _speechRecognition.activate(loc).then(
          (result) => setState(() => _isAvailable = result),
        );
    _speechRecognition.setRecognitionStartedHandler(
      () => setState(() => _isListening2 = true),
    );
    _speechRecognition.setRecognitionResultHandler(
      (String speech) => setState(
        () => convertedText = speech,
      ),
    );
    _speechRecognition.setRecognitionCompleteHandler(
      (String speech) => setState(() => _isListening2 = false),
    );
    if (_isAvailable && !_isListening2) {
      _speechRecognition
          .listen()
          .then((result) => setState(() => convertedText = convertedText));
    }
    Future.delayed(Duration(seconds: 5), () {
      convert2();
    });
  }

  Future<void> convert2() async {
    const url = "http://rahuldev153.pythonanywhere.com/api";
    final response = await http.post(Uri.parse(url),
        headers: {"Content-Type": "application/json"},
        body: json.encode({'text': convertedText, 'lang': language}));
    print("language2" + "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

    if (isListening == true) {
      stop();
    }
    recordedText = response.body;
    print(recordedText + "******************************");
    setState(() {
      recordedText = response.body;
      langList1.add(convertedText);
      langList2.add(recordedText);
      speak(recordedText);
    });
  }

  void stop() {
    if (_isListening) {
      _speechRecognition.stop().then((result) => setState(
            () {
              _isListening = result;
              recordedText = resultText;
            },
          ));
    }
  }

  speak(text) async {
    await flutterTts.setLanguage("hi");
    await flutterTts.setPitch(0.8);
    await flutterTts.speak(text);
  }
}
